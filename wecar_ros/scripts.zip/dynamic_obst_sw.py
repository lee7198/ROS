#! /usr/bin/env python
# -*- coding:utf-8 -*-

import imp
import rospy
import math
import numpy as np
from std_msgs.msg import Float64
from sensor_msgs.msg import PointCloud
from morai_msgs.msg import EgoVehicleStatus
from nav_msgs.msg import Path

# 346 383
# 499 544

area_check = False
car_position = np.array([[0,0]])

class DynamicObstacle:
    def __init__(self):
        rospy.init_node("dynamic_obstacle_node", anonymous=False)
        self.pc_sub = rospy.Subscriber("/PC_MapData", PointCloud, self.dyno_cb)
        self.ego_sub = rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.ego_cb)
        self.wayp_check_sub = rospy.Subscriber("/current_waypoint", Float64, self.area_check_cb)
        self.local_sub = rospy.Subscriber("/local_path", Path, self.local_cb)

        self.ego_pub = rospy.Publisher("/Dynamic_vel_set", Float64, queue_size=10)
        # self.ego_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=10)

    def area_check_cb(self, data):
        global area_check
        current_waypoint = data.data
        if 678 <= current_waypoint <= 724 or 840 <= current_waypoint <= 881:
            area_check = True
            print("dynamic obstacle area! {}".format(area_check) )
        else:
            area_check = False
        # print("dynamic obstacle area! {}".format(area_check) )

    def dyno_cb(self, data):
        global local_path
        set_speed = Float64()
        lidar_points = data.points

        set_speed.data = 10
        if area_check == True:
            dist = 100
            for points in local_path:
                for j in range(len(lidar_points)):
                    lidar_x = lidar_points[j].x
                    lidar_y = lidar_points[j].y
                    dist = math.sqrt(pow(points[0]-lidar_x,2)+pow(points[1]+0.5-lidar_y,2))
                    if dist <= 1: #1
                        lidar_index = j
                        break
                if dist <= 1: #1
                    break
        
            if dist <= 1: #1
                obj_dist = math.sqrt(pow(car_position[0][0]-lidar_points[lidar_index].x,2)+pow(car_position[0][1]-lidar_points[lidar_index].y,2))
                print("Distance of object : {}".format(obj_dist))
                if obj_dist <= 1.5:
                    set_speed.data = 0
                else:
                    set_speed.data = (obj_dist-1.5)*2


        self.ego_pub.publish(set_speed)            

    def ego_cb(self, data):
        global car_position
        car_x = data.position.x
        car_y = data.position.y
        car_position = np.array([[car_x,car_y]])

    
    def local_cb(self, data):
        global local_path
        local_path = []
        for i in range(len(data.poses)):
            local_x = data.poses[i].pose.position.x
            local_y = data.poses[i].pose.position.y
            local_path.append([local_x, local_y]) 

if __name__ == "__main__":
    DynamicObstacle()
    rospy.spin()