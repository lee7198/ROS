#! /usr/bin/env python
# -*- coding:utf-8 -*-

import math
import rospy
import numpy as np
from sensor_msgs.msg import PointCloud
from geometry_msgs.msg import Point32
from morai_msgs.msg import EgoVehicleStatus

class LidarDataMap:
    def __init__(self):
        rospy.init_node("PC_data_based_Map", anonymous=False)
        self.sub_pc = rospy.Subscriber("/PC_data", PointCloud, self.PC_to_Map_cb)
        self.sub_ego = rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.receive_Ego_cb)
        self.pub_pc_map = rospy.Publisher("/PC_MapData", PointCloud, queue_size=10)

        
    def receive_Ego_cb(self, data):
        global car_position
        heading = data.heading
        car_x = data.position.x
        car_y = data.position.y
        # heading = heading*math.pi/180
        n = math.floor(heading / 360)
        Heading_180_to_360 = -(heading - n * 360)*math.pi/180 #라디안변환
        car_position = np.array([[car_x, car_y, Heading_180_to_360]]) 
        # print(Heading_180_to_360)
        
        # car_position = np.array([[car_x, car_y, heading]])

        # print(car_position)
        # print(type(car_position))


    def PC_to_Map_cb(self, data):
        header = data.header
        PC_MapData = PointCloud()
        PC_MapData.header = header
        for i in car_position:

            for j in range(len(data.points)):
                #차량의 맵좌표 추출
                sensor_x = data.points[j].x
                sensor_y = data.points[j].y
                
                #회전변환, 차량좌표 to 맵좌표
                # rotate_x = (trans_x*math.cos(i[2]))-(trans_y*math.sin(i[2]))
                # rotate_y = (trans_x*math.sin(i[2]))+(trans_y*math.cos(i[2]))
                rotate_x = sensor_x*math.cos(i[2])+sensor_y*math.sin(i[2])
                rotate_y = -sensor_x*math.sin(i[2])+sensor_y*math.cos(i[2])

                #이동변환, 변환된 라이다 좌표 to 맵좌표
                map_x = rotate_x + i[0] #맵에서 차량 좌표
                map_y = rotate_y + i[1]
                
                
                # print("map x", map_x)
                # print("map y", map_y)
                PC_MapData.points.append(Point32(map_x, map_y, 0))

        self.pub_pc_map.publish(PC_MapData)
        

if __name__ == "__main__":
    try:
        LidarDataMap()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass