#! /usr/bin/env python
# -*- coding:utf-8 -*-
from cgi import print_directory
import numpy as np
import rospy
import math
from std_msgs.msg import Float64
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import PointCloud
from morai_msgs.msg import EgoVehicleStatus

# rotary_waypoints = ([12.623289108276367, -1.374843716621399],
# [13.13288688659668, -1.3180434703826904]
# ,[13.595109939575195, -1.1247962713241577]
# ,[13.94007682800293, -0.7594069838523865]
# ,[14.132795333862305, -0.29565346240997314]
# ,[14.14057445526123, 0.2099534273147583]
# ,[13.977616310119629, 0.6943334341049194]
# ,[13.64093017578125, 1.0750136375427246]
# ,[13.18904972076416, 1.3067909479141235]
# ,[12.685673713684082, 1.3568036556243896]
# ,[12.203765869140625, 1.2191333770751953]
# ,[11.788557052612305, 0.9074369668960571]
# ,[11.52014446258545, 0.479469358921051]
# ,[11.432727813720703, -0.015340026468038559]
# ,[11.540022850036621, -0.5132615566253662]
# ,[11.816130638122559, -0.9335846304893494]
# ,[12.22353744506836, -1.2339578866958618])

#차량이 있을때 진입하면 안되는 위치 == 진입불가지역
rotary_waypoints = ([13.94007682800293, -0.7594069838523865]
,[14.132795333862305, -0.29565346240997314]
,[14.14057445526123, 0.2099534273147583]
,[13.977616310119629, 0.6943334341049194])

rotary_waypoints_2 = ([11.788557052612305, 0.9074369668960571]
,[11.52014446258545, 0.479469358921051]
,[11.432727813720703, -0.015340026468038559]
,[11.540022850036621, -0.5132615566253662])

#Tracking area
# rotary_acc_1 =([14.1072044373,0.378770291805]	
# ,[13.8834648132,0.830594718456]
# ,[13.5053596497,1.16508674622]
# ,[13.019821167,1.33817005157]
# ,[12.51197052,1.31785047054]   
# ,[12.0448284149,1.12642073631]
# ,[11.6718912125,0.760740697384]
# ,[11.4617338181,0.283430069685]
# ,[11.4526939392,-0.231405213475]
# ,[11.6392679214,-0.706213474274]
# ,[11.9636774063,-1.08921384811]
# ,[12.2912216187,-1.48772716522]
# ,[12.3124370575,-1.99009120464])

# rotary_acc_2 = ([11.5570106506,-0.561326622963] 
# ,[11.8504085541,-0.977102279663] 
# ,[12.2869291306,-1.2579678297] 
# ,[12.7846698761,-1.35252666473] 
# ,[13.2905044556,-1.25209009647] 
# ,[13.7254753113,-0.984864711761] 
# ,[14.0131015778,-0.564238488674] 
# ,[14.1622085571,-0.0752274170518] 
# ,[14.09425354,0.423179388046] 
# ,[13.8399925232,0.85594022274] 
# ,[13.4796943665,1.22511601448] 
# ,[13.3329696655,1.71091282368])

#first rotary mission
m1_start_wayp = 100 #
m1_end_wayp = 105
m1_traking_wap = 112
# m1_traking_wap = 100


#second rotary mission
m2_start_wayp = 459
m2_end_wayp = 465
m2_traking_wap = 476
# m2_traking_wap = 450

mission_enter_area = 0 #False
rt_tracking_area = 0 #false
car_position = np.array([[0,0]])

class RotaryMission:
    def __init__(self):
        rospy.init_node("Rotary_mission_node", anonymous=False) 
        #Subscriber
        self.wayp_sub = rospy.Subscriber("/current_waypoint", Float64, self.area_check_cb)
        self.pc_sub = rospy.Subscriber("/PC_MapData", PointCloud, self.mission_check_cb)
        self.ego_sub = rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.ego_cb)
        self.local_sub = rospy.Subscriber("/local_path", Path, self.local_cb)
        #Publisher
        self.rtway_pub = rospy.Publisher("/Rotary_check_path", Path, queue_size=10)
        self.rtway2_pub = rospy.Publisher("/Rotary_check_path_2", Path, queue_size=10)
        self.ego_pub = rospy.Publisher("/Rotary_vel_set", Float64, queue_size=10)
        # self.ego_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=10)
        rospy.spin()



    def area_check_cb(self, data):
        global mission_enter_area
        global rt_tracking_area
        current_waypoint = data.data
        # print("current wayp : {}".format(current_waypoint))
        #현재 웨이포인트가 미션1구간 '이거나' 미션2구간에 속해있을때 == mission_enter_area = True
        if m1_start_wayp <= current_waypoint <= m1_end_wayp:
            mission_enter_area = 1 #mission area 1 flag
            # print("Mission Area 1")
        elif m2_start_wayp <= current_waypoint <= m2_end_wayp:
            mission_enter_area = 2 #mission area 2 flag
            # print("Mission Area 2")
        else:
            mission_enter_area = 0 #False

        if m1_traking_wap <= current_waypoint <= m1_traking_wap+50:
            rt_tracking_area = 1 #mission area 1 flag
            # print("Tracking Area 1")
        elif m2_traking_wap <= current_waypoint <= m2_traking_wap+50:
            rt_tracking_area = 2 #mission area 2 flag
            # print("Tracking Area 2")
        else:
            rt_tracking_area = 0 #False

        # print("Mission Area : {}".format(mission_enter_area))
        # print("Tracking Area : {}".format(rt_tracking_area))

    def mission_check_cb(self, data):
        lidar_points = data.points
        checking = True
        self.path_viz()
        set_speed = Float64()

        #Rotary entering check
        set_speed.data = 10
        if mission_enter_area == 1 or mission_enter_area == 2:
            print("TEESTASEAWDAWD")
            for i in range(len(lidar_points)):
                lidar_x = lidar_points[i].x
                lidar_y = lidar_points[i].y
                if mission_enter_area == 1:
                    for j in rotary_waypoints:
                        #distance check between lidar data and Check Path 
                        zone_range = math.sqrt(pow(j[0]-lidar_x,2)+pow(j[1]-lidar_y,2))
                        if zone_range < 0.5:
                            checking = False
                elif mission_enter_area == 2:
                    for j in rotary_waypoints_2:
                        #distance check between lidar data and Check Path 
                        zone_range = math.sqrt(pow(j[0]-lidar_x,2)+pow(j[1]-lidar_y,2))
                        if zone_range < 0.5:
                            checking = False

                print("rotary Entering : {}".format(checking))

                if checking == False:
                    set_speed.data = 0
                    break
            if checking == True:
                set_speed.data = 5

#in Rotary
        if rt_tracking_area == 1 or rt_tracking_area == 2:
            global local_path
            # print(local_path)
            dist = 100
            path_index = 0
            for points in local_path:
                for j in range(len(lidar_points)):
                    lidar_x = lidar_points[j].x
                    lidar_y = lidar_points[j].y
                    dist = math.sqrt(pow(points[0]-lidar_x,2)+pow(points[1]-lidar_y,2))
                    if dist <= 1:
                        lidar_index = j
                        break
                if dist <= 1:
                    break
                path_index += 1

            if dist <= 1:
                obj_dist = math.sqrt(pow(car_position[0][0]-lidar_points[lidar_index].x,2)+pow(car_position[0][1]-lidar_points[lidar_index].y,2))
                print("Distance of object : {}".format(obj_dist))
                print("path index : {}, lidar index {}".format(path_index, lidar_index))
                if checking == True:
                    if 1 <= obj_dist: 
                        set_speed.data = obj_dist*2
                    else:
                        set_speed.data = 0.0
            else:
                set_speed.data = 5

        self.ego_pub.publish(set_speed)

    #Rotary Check Path Vizualization
    def path_viz(self):
        viz_path = Path() 
        viz_path.header.frame_id='map'
        for i in rotary_waypoints:
            check_path_pose = PoseStamped()
            check_path_pose.pose.position.x = i[0]
            check_path_pose.pose.position.y = i[1]
            check_path_pose.pose.orientation.x=0
            check_path_pose.pose.orientation.y=0
            check_path_pose.pose.orientation.z=0
            check_path_pose.pose.orientation.w=1
            viz_path.poses.append(check_path_pose)
        self.rtway_pub.publish(viz_path)

        viz_path_2 = Path() 
        viz_path_2.header.frame_id='map'
        for i in rotary_waypoints_2:
            check_path_pose_2 = PoseStamped()
            check_path_pose_2.pose.position.x = i[0]
            check_path_pose_2.pose.position.y = i[1]
            check_path_pose_2.pose.orientation.x=0
            check_path_pose_2.pose.orientation.y=0
            check_path_pose_2.pose.orientation.z=0
            check_path_pose_2.pose.orientation.w=1
            viz_path_2.poses.append(check_path_pose_2)
        
        self.rtway2_pub.publish(viz_path_2)

    def ego_cb(self, data):
        global car_position
        car_x = data.position.x
        car_y = data.position.y
        car_position = np.array([[car_x,car_y]])

    def local_cb(self, data):
        global local_path
        local_path = []
        for i in range(len(data.poses)):
            local_x = data.poses[i].pose.position.x
            local_y = data.poses[i].pose.position.y
            local_path.append([local_x, local_y]) 
        # print(local_path)
        

            
            



if __name__ == "__main__":
    try:
        RotaryMission()
    except:
        print("rotary.py error!")
