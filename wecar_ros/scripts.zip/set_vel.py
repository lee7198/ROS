#! /usr/bin/env python
#-*- coding:utf-8 -*-

from rosdep2 import DownloadFailure
import rospy
from std_msgs.msg import Float64

# global rotary_vel
rotary_vel = []

wayp = 0.0


class VelocityDicision:
    def __init__(self):
        #subscriber
        rospy.init_node("velocity_contron_node", anonymous=False)
        self.wecar_sub = rospy.Subscriber("/Rotary_vel_set", Float64, self.rotary_vel_set)
        self.rotary_sub = rospy.Subscriber("/wecar_vel_set", Float64, self.velocity_cb)
        self.wayp_sub = rospy.Subscriber("/current_waypoint", Float64, self.wayp_check_cb)

        #publisher
        self.vel_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)

    def wayp_check_cb(self, data):
        global wayp
        wayp = data.data

    # global rotary_vel
    def rotary_vel_set(self, data):
        global rotary_vel
        rotary_vel_list = [data.data]
        for i in rotary_vel_list:
            rotary_vel = i
        
        # print("rotary vel : {}".format(rotary_vel))
        # return data.data
    
    def velocity_cb(self, data):
        # global rotary_vel
        # rotary_speed = self.rotary_vel_set(self)
        min_vel = Float64()
        get_vel_list = []
        # print(data)
        wecar_vel = data.data
        vel_data = [data.data]
        if wayp <= 10:
            min_vel.data = wecar_vel
            self.vel_pub.publish(min_vel)
            
        for i in vel_data:
            get_vel_list.append(i)
            get_vel_list.append(rotary_vel)
            set_vel = min(get_vel_list)
            min_vel.data = set_vel
            self.vel_pub.publish(min_vel)
            print("get vel list {}".format(get_vel_list))
            del get_vel_list[0:]
            # rotary_vel = []
            print("get vel list2222222222 {}".format(get_vel_list))
            
        # all_vel = [rotary_speed, wecar_speed]
        # # print(all_vel)
        # print(wecar_speed)

        # for i in all_vel:
        #     min_vel = min(i[0],i[1])
        #     print("minvel : {}".format(min_vel))
        #     self.vel_sub.publish(min_vel)

        
if __name__ == "__main__":
    try:
        VelocityDicision()
        rospy.spin()
    except:
        print("velocity set error!")
    # VelocityDicision()
    # rospy.spin()
