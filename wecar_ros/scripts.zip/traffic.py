#!/usr/bin/env python
# -*- coding: utf-8 -*-


from operator import truediv
import rospy
import math
from std_msgs.msg import Float64, Bool
from morai_msgs.msg import EgoVehicleStatus, GetTrafficLightStatus



traffic_wp = [7.289229869842529, -2.0228052139282227]

traffic_wp2 = [6.222927570343018, 2.038097858428955]


class traffic():
    def __init__(self):
        rospy.init_node('traffic')
        rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.traffic_dis)
        rospy.Subscriber("/GetTrafficLightStatus", GetTrafficLightStatus, self.traffic_sign)
        self.send_speed = rospy.Publisher("/Traffic_vel_set", Float64, queue_size = 1)
        #self.trf_sign = rospy.Publisher("/trf_sign", Bool, queue_size=10)
        self.motor_speed1 = 10
        self.traf_mission = False
        self.stop = False
        self.count = 0
        
        rospy.spin()



    def traffic_dis(self, data):  #차와 신호등과의 거리 계산

        map_x = data.position.x
        map_y = data.position.y

        traffic_x = traffic_wp[0]
        traffic_y = traffic_wp[1]

        traffic_x2 = traffic_wp2[0]
        traffic_y2 = traffic_wp2[1]
        
        traf_car_dis = math.sqrt(math.pow((traffic_x - map_x),2) + math.pow((traffic_y - map_y),2))
        traf_car_dis2 = math.sqrt(math.pow((traffic_x2 - map_x),2) + math.pow((traffic_y2 - map_y),2))
        
        if traf_car_dis <= 0.3:
            self.traf_mission = True
        else:
            self.traf_mission = False
            if traf_car_dis2 <= 0.3:
                self.traf_mission = True
            else:
                self.traf_mission = False
    
    def traffic_sign(self, data):  #신호등 색깔 구분
        trfsign = True
        traffic_color = data.trafficLightStatus  #신호등 색깔 데이터
        if self.traf_mission == True:
            if traffic_color != 33:
                trfsign = False
                self.motor_speed1 = 0
            else:
                self.motor_speed1 = 10
        else:
            self.motor_speed1 = 10



        self.send_speed.publish(self.motor_speed1)
    


if __name__ == '__main__':
    try:
        traffic()
    except rospy.ROSInterruptException:
        pass