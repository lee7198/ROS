#! /usr/bin/env python
# -*- coding:utf-8 -*-

import math
import rospy
import numpy as np
from std_msgs.msg import Float64
from time import sleep
from morai_msgs.msg import EgoVehicleStatus

stop_wp = [19.3608951569, -2.0192383766]
class stop:
    def __init__(self):
        rospy.init_node('stop', anonymous=False)
        rospy.Subscriber("/Ego_topic", EgoVehicleStatus, self.stop)
        self.send_spd = rospy.Publisher("/stop_vel_set", Float64, queue_size = 1)

        self.speed = 10
        self.count = 0

    def stop(self, data):

        car_x = data.position.x
        car_y = data.position.y

        dx = stop_wp[0] - car_x
        dy = stop_wp[1] - car_y


        dist = math.sqrt(dx*dx + dy*dy)



        if dist <= 0.3:
            self.speed = 0
        else:
            self.speed = 10

        if dist <= 0.25:
            sleep(6)
            self.speed = 10

        # if self.speed == 0:
        #     while True:
        #         sleep(1)
        #         self.count += 1
        #         print(self.count)
        #         if self.count == 6:
        #             break
        #     self.speed = 10
   
        self.send_spd.publish(self.speed)

if __name__ == "__main__":
    try:
        stop()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
    