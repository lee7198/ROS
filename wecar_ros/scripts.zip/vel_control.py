#! /usr/bin/env python
#-*- coding:utf-8 -*-

import rospy
from std_msgs.msg import Float64

spd_list = []

class VelocityDicision():
    def __init__(self):
        rospy.init_node("velocity_control_node", anonymous=False)
        rospy.Subscriber("/Rotary_vel_set", Float64, self.rotary_set)
        rospy.Subscriber("/wecar_vel_set", Float64, self.wecar_set)
        rospy.Subscriber("/Traffic_vel_set", Float64, self.traffic_set)
        rospy.Subscriber("/Dynamic_vel_set", Float64, self.dynamic_set)
        #rospy.Subscriber("/stop_vel_set", Float64, self.stop_set)
        rospy.Subscriber("commands/motor/speed", Float64, self.spd_set)

        self.vel_pub = rospy.Publisher("/commands/motor/speed", Float64, queue_size=1)

        self.wecar_vel = 1500
        self.rotary_vel = 1500
        self.traffic_vel = 1500
        self.dynamic_vel = 1500
        #self.stopline_vel = 1500

    def wecar_set(self, data):
        self.wecar_vel = data.data

    def rotary_set(self, data):
        self.rotary_vel = data.data

    def traffic_set(self, data):
        self.traffic_vel = data.data

    def dynamic_set(self, data):
        self.dynamic_vel = data.data



    # def stop_set(self, data):
        # self.stopline_vel = data.data

    def spd_set(self, data):
        print("lllllllll")
        spd_list = []        
        spd_list.append(self.wecar_vel)
        spd_list.append(self.rotary_vel)
        spd_list.append(self.traffic_vel)
        spd_list.append(self.dynamic_vel)
        
        
   
        # if self.wecar_vel < self.rotary_vel:
            # if self.wecar_vel < self.traffic_vel:
                # if self.wecar_vel < self.dynamic_vel:
                    # spd_vel = self.wecar_vel
                # else:
                    # spd_vel = self.dynamic_vel
            # else:
                # spd_vel = self.traffic_vel
        # else:
            # spd_vel = self.rotary_vel
        # 
        # print(spd_vel)
        self.vel_pub.publish(min(spd_list))

if __name__ == "__main__":
    try:
        VelocityDicision()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass